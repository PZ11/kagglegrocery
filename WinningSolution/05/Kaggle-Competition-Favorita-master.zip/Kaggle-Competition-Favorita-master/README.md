# Kaggle-Competition-Favorita
5th place solution for Kaggle competition Favorita Grocery Sales Forecasting

More descriptions coming...
